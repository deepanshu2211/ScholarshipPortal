# Scholarship-portal
Web based portal in HTML , Javascript and PHP made for alumni association of COEP which analyzes the student's data and optimally selects the best candidate(s) for a particular scholarship based on various criteria
